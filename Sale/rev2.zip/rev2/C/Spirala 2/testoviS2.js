let assert = chai.assert;
kalendar = document.getElementById("calendar");

describe ('Kalendar', function(){
   
        ///////////////////////////////////////////////
        //testovi za testiranje iscrtavanja kalendara//
        ///////////////////////////////////////////////

        it('should draw 30 days/divs when month is september', function() {
            Kalendar.iscrtajKalendar(kalendar, 8);
            
            //ocekivano je da za mjesec semptembar kojeg cemo pozvati imamo 30 dana
            //31 dan mjeseca ce biti sakriven
            //2*31 - 1 daje taj dan u mjesecu kako je vidljivo iz petlje u modulu Kalendar pozicija = 2*i-1
            assert.equal(kalendar.childNodes[5].childNodes[61].style.visibility, "hidden");
        })

        it('should draw 31 days/divs when month is december', function(){
            Kalendar.iscrtajKalendar(kalendar, 11);
            assert.equal(kalendar.childNodes[5].childNodes[61].style.visibility, "visible");

        })

        it('first day should be on friday', function(){
            Kalendar.iscrtajKalendar(kalendar, 10); 

            let kalendarDani = kalendar.childNodes[5].childNodes[1].style.gridColumnStart; 
            assert.equal(kalendarDani, 5, "Prvi dan novembra je u petak");
        })

        it('last day should be on saturday', function(){
            Kalendar.iscrtajKalendar(kalendar, 10);
            
            //u gridu u kojem cuvamo kalendar imamo 7x5=35 mjesta
            //potrebno je doznati pocetak prvog elementa
            let kalendarDani = kalendar.childNodes[5].childNodes[1].style.gridColumnStart - 1;
            
            //sabrati ga s brojem dana tog mjesec
            kalendarDani = kalendarDani + 30;
            //krajnji rezultat dobijamo kao 35 - kalendarDani
            //da bi dan bio nedjelja prethodni rezultat mora biti 0
            //za subotu rezultat je 1, petak bi imao rezultat 2 itd (dakle posmatramo kao invertovano indeksiranje niza)
            
            assert.equal(35 - kalendarDani, 1, "Zadnji dan novembra je u subotu");
        })

        it('days in january = 31, first day on tuesday', function(){
            Kalendar.iscrtajKalendar(kalendar, 0);

            let kalendarDani = kalendar.childNodes[5].childNodes[1].style.gridColumnStart; 
            assert.equal(kalendarDani, 2, "Prvi dan novembra je u petak");
            assert.equal(kalendar.childNodes[5].childNodes[61].style.visibility, "visible");
            
        })

        it('write december above days', function(){
            Kalendar.iscrtajKalendar(kalendar, 11);

            let naziv = kalendar.childNodes[1].textContent;

            assert.equal(naziv, "Decembar:");
        })

        it('write february above days', function(){
            Kalendar.iscrtajKalendar(kalendar, 1);

            let naziv = kalendar.childNodes[1].textContent;

            assert.equal(naziv, "Februar:");
        })

        //////////////////////////////////////////
        //testovi za testiranje obojenja zauzeca//
        //////////////////////////////////////////

        it('nema bojenje zauzeca jer podaci nisu ucitani', function(){
            Kalendar.ucitajPodatke([], []);
            Kalendar.iscrtajKalendar(kalendar, 10);
            Kalendar.obojiZauzeca(kalendar, null, null, null, null);
            
            var slobodni = 0;
            var dani = kalendar.childNodes;

            for(var i = 1; i <= dani[5].childElementCount; i++){
                var bojenje = dani[5].childNodes[i*2-1].style.backgroundImage;

                if(bojenje.includes('-webkit-linear-gradient(bottom, rgb(8, 247, 9), rgb(8, 247, 9) 40%, transparent 0%, transparent 100%)'))
                    slobodni++;
            }

            assert.equal(slobodni, 31);
        })

        it('bojenje dana za dupla zauzeca na taj isti dan se mora realizirati', function(){
            Kalendar.ucitajPodatke([], [{"datum":"20.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"20.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");

            var dan = kalendar.childNodes[5].childNodes[2*20-1].style.backgroundImage;

            assert.include(dan, 'linear-gradient(bottom, rgb(255, 19, 19), rgb(255, 19, 19) 40%, transparent 0%, transparent 100%)');
        })

        it('nema bojenja zauzeca za periodicno zauzece jer je semestar suprotni', function(){
            Kalendar.ucitajPodatke([{"dan":"2", "semestar":"ljetni", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xy"}], []);
            Kalendar.obojiZauzeca(kalendar, 10, "0-01", null, null);

            var slobodni = 0;
            var dani = kalendar.childNodes;

            for(var i = 1; i <= dani[5].childElementCount; i++){
                var bojenje = dani[5].childNodes[i*2-1].style.backgroundImage;

                if(bojenje.includes('-webkit-linear-gradient(bottom, rgb(8, 247, 9), rgb(8, 247, 9) 40%, transparent 0%, transparent 100%)'))
                    slobodni++;
            }

            assert.equal(slobodni, 31);
        })

        it('nema bojenja kada su zauzeca u drugom mjesecu', function(){
            Kalendar.ucitajPodatke([{"dan":"2", "semestar":"ljetni", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xy"}], [{"datum":"20.12.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            
            Kalendar.obojiZauzeca(kalendar, 10, '0-01', null, null);

            var slobodni = 0;
            var dani = kalendar.childNodes;

            for(var i = 1; i <= dani[5].childElementCount; i++){
                var bojenje = dani[5].childNodes[i*2-1].style.backgroundImage;

                if(bojenje.includes('-webkit-linear-gradient(bottom, rgb(8, 247, 9), rgb(8, 247, 9) 40%, transparent 0%, transparent 100%)'))
                    slobodni++;
            }

            assert.equal(slobodni, 31);
        })

        it('oboji sve dane kada imamo zauzeca za svaki dan', function(){
            Kalendar.ucitajPodatke([], [{"datum":"01.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"02.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"03.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"04.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"05.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"06.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"07.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"08.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"09.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"10.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"11.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"12.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"13.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"14.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"15.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"16.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"17.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"18.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"19.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"20.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"21.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"22.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"23.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"24.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"25.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"26.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"27.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"28.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"29.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        {"datum":"30.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"},
                                        ]);

            Kalendar.obojiZauzeca(kalendar, 10, '0-01', null, null);

            var zauzeca = 0;
            var dani = kalendar.childNodes;

            for(var i = 1; i <= dani[5].childElementCount; i++){
                var bojenje = dani[5].childNodes[i*2-1].style.backgroundImage;

                if(bojenje.includes('linear-gradient(bottom, rgb(255, 19, 19), rgb(255, 19, 19) 40%, transparent 0%, transparent 100%)'))
                    zauzeca++;
            }

            assert.equal(zauzeca, 30);
        })

        it('dva puta zovi bojenje zauzeca, treba ostati isto', function(){
            Kalendar.ucitajPodatke([], [{"datum":"20.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");

            var dan = kalendar.childNodes[5].childNodes[2*20-1].style.backgroundImage;

            assert.include(dan, 'linear-gradient(bottom, rgb(255, 19, 19), rgb(255, 19, 19) 40%, transparent 0%, transparent 100%)');
        })

        it('bojenje kalendara prilikom poziva drugih podataka - obojenja ne smiju ostati od prethodnog bojenja', function(){
            Kalendar.ucitajPodatke([], [{"datum":"20.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");
            Kalendar.ucitajPodatke([], []);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");

            var slobodni = 0;
            var dani = kalendar.childNodes;

            for(var i = 1; i <= dani[5].childElementCount; i++){
                var bojenje = dani[5].childNodes[i*2-1].style.backgroundImage;

                if(bojenje.includes('-webkit-linear-gradient(bottom, rgb(8, 247, 9), rgb(8, 247, 9) 40%, transparent 0%, transparent 100%)'))
                    slobodni++;
            }

            assert.equal(slobodni, 31);

        })

        it('oboji prvi dan mjeseca', function(){
            Kalendar.ucitajPodatke([], [{"datum":"01.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");

            var dani = kalendar.childNodes[5].childNodes[1];
            assert.include(dani.style.backgroundImage, 'linear-gradient(bottom, rgb(255, 19, 19), rgb(255, 19, 19) 40%, transparent 0%, transparent 100%)');
        })

        it('oboji zadnji dan mjeseca', function(){
            Kalendar.ucitajPodatke([], [{"datum":"30.11.2019", "pocetak":"14:00", "kraj":"15:00", "naziv":"0-01", "predavac":"xx"}]);
            Kalendar.obojiZauzeca(kalendar, 10, "1-02", "14:00", "15:00");

            var dani = kalendar.childNodes[5].childNodes[2*30-1];
            assert.include(dani.style.backgroundImage, 'linear-gradient(bottom, rgb(255, 19, 19), rgb(255, 19, 19) 40%, transparent 0%, transparent 100%)');
        })
            
});
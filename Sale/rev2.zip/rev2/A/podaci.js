var podaci_periodicni=[
    {
        dan: 3,
        semestar: "zimski",
        pocetak: "08:00",
        kraj: "09:00",
        naziv: "0-01",
        predavac:"profesor"
    
    },
    {
    dan: 5,
    semestar: "zimski",
    pocetak: "09:05",
    kraj: "10:05",
    naziv: "0-01",
    predavac:"profa"
},
{
    dan: 6,
    semestar: "zimski",
    pocetak: "12:00",
    kraj: "13:00",
    naziv: "0-01",
    predavac:"profesor"

},
{
    dan: 6,
    semestar: "zimski",
    pocetak: "22:00",
    kraj: "23:00",
    naziv: "EE2",
    predavac:"profesor"

},
{
    dan: 2,
    semestar: "ljetni",
    pocetak: "08:00",
    kraj: "09:00",
    naziv: "0-01",
    predavac:"profesor"

}
];

var podaci_vanredni=[{
    datum: "07.10.2019",
    pocetak: "10:00",
    kraj: "11:00",
    naziv: "0-01",
    predavac: "profesor"
},
{
    datum: "04.07.2019",
    pocetak: "10:00",
    kraj: "11:00",
    naziv: "0-01",
    predavac: "profesor"
},
{
    datum: "01.10.2019",
    pocetak: "10:00",
    kraj: "11:00",
    naziv: "0-01",
    predavac: "profesor"
},
{
    datum: "15.12.2019",
    pocetak: "10:00",
    kraj: "11:00",
    naziv: "0-02",
    predavac: "profesor"
}];

function dajPeriodicna() {
    return podaci_periodicni;
}

function dajVanredna() {
    return podaci_vanredni;
}

function kojiMjesec(nekiMjesec) {
    var prva = nekiMjesec[3];
    var druga = nekiMjesec[4];
    return (parseInt(prva.concat(druga)));
}

function kojiDan(datumNeki) {
    var prva = datumNeki[0];
    var druga = datumNeki[1];
    return (parseInt(prva.concat(druga)));
}
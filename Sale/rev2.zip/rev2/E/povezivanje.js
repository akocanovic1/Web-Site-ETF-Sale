function poziv1() {

    Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), globDatum.getMonth() + 1);
    Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar"), globDatum.getMonth() + 1);
}


function poziv2() {

    Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), globDatum.getMonth() - 1);
    Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar"), globDatum.getMonth() + 1);

}

function poziv3() {
    console.log("plsdwoofas");
    Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar"), globDatum.getMonth());

}


window.addEventListener('load', function() {

    Kalendar.iscrtajKalendar(document.getElementsByClassName("kalendar"), globDatum.getMonth());

    //Hardkodirane podatke ubaciti ovdje



    var nizPeriodicnih = [

        {
            dan: 4,
            semestar: "ljetni",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA2",
            predavac: "Zeljko Juric"
        },
        {
            dan: 2,
            semestar: "zimski",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA2",
            predavac: "Zeljko Juric"
        }
    ]

    var nizPeriodicnih2 = [

        {
            dan: 1,
            semestar: "ljetni",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA2",
            predavac: "Zeljko Juric"
        },
        {
            dan: 3,
            semestar: "zimski",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA2",
            predavac: "Zeljko Juric"
        }
    ]

    var nizVanrednih = [{
        datum: "12.10.2019",
        pocetak: "12:00",
        kraj: "14:45",
        naziv: "EE1",
        predavac: "Test"
    }]


    Kalendar.ucitajPodatke(nizPeriodicnih, nizVanrednih);
    Kalendar.ucitajPodatke(nizPeriodicnih2, nizVanrednih);


    Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar"), 10);
})